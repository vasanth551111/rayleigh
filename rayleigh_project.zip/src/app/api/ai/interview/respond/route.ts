import Groq from "groq-sdk";
import { NextResponse } from "next/server";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

const PERSONALITIES: Record<string, string> = {
  friendly: "You are Alex, a warm, encouraging interviewer. You acknowledge answers briefly before following up.",
  corporate: "You are Ms. Chen, a formal corporate interviewer. You are precise and methodical.",
  tough: "You are David, a demanding director. You probe weaknesses and never accept vague answers.",
  faang: "You are a Staff Engineer at a top-tier tech company. You expect deep technical reasoning.",
  startup: "You are a startup founder. You care about hustle, impact, and ownership.",
  hr: "You are Jordan, an experienced HR recruiter focused on soft skills and culture fit.",
};

export async function POST(req: Request) {
  try {
    const {
      role,
      domain,
      level,
      interviewType,
      personality = "friendly",
      currentQuestion,
      questionIndex,
      userAnswer,
      allAnswers = [],
      fillerCount = 0,
      answerDuration = 0,
    } = await req.json();

    const systemPrompt = PERSONALITIES[personality] || PERSONALITIES.friendly;

    // Analyze the answer quality to decide how to follow up
    const analysisPrompt = `You are conducting a ${interviewType} interview for a ${level}-level ${role} (${domain}).

Current question asked: "${currentQuestion}"
Candidate's answer: "${userAnswer}"
Filler words detected: ${fillerCount}
Answer duration: ${answerDuration} seconds
Question index: ${questionIndex}

Analyze the answer and decide the best follow-up action:
1. If the answer is VAGUE or INCOMPLETE: Ask a specific clarifying follow-up
2. If the answer mentions a PROJECT or EXPERIENCE: Dig deeper (what stack? what challenge? what outcome?)
3. If the answer is STRONG and COMPLETE: Acknowledge briefly and transition to the next main topic
4. If the answer shows a WEAKNESS: Politely probe it further
5. If the answer mentions a TECHNICAL CONCEPT: Test depth of understanding

Previous answers summary: ${allAnswers.slice(-2).join(" | ")}

Generate your response as the interviewer. It must:
- Be 2-4 sentences maximum
- Acknowledge the answer in 1 sentence (briefly, naturally — e.g., "That's interesting." or "Good point.")
- Then either ask a follow-up OR smoothly transition with a new question
- Sound completely natural, like a real human interviewer talking
- NOT include any formatting, headers, or meta-instructions
- End with exactly one question

Respond only as the interviewer, in first person, speaking directly to the candidate.`;

    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: analysisPrompt },
      ],
      temperature: 0.75,
      max_tokens: 200,
      stream: false,
    });

    const response = completion.choices[0].message.content || "";

    // Determine if this is a follow-up or moving to next question
    const isFollowUp = response.toLowerCase().includes("?") &&
      (response.toLowerCase().includes("tell me more") ||
       response.toLowerCase().includes("elaborate") ||
       response.toLowerCase().includes("how did") ||
       response.toLowerCase().includes("what was") ||
       response.toLowerCase().includes("can you") ||
       response.toLowerCase().includes("walk me"));

    return NextResponse.json({
      response,
      isFollowUp,
      nextQuestionIndex: isFollowUp ? questionIndex : questionIndex + 1,
    });

  } catch (error: any) {
    console.error("Interview respond error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
